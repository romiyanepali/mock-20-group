package be.ucll.controller;

import be.ucll.model.Publication;
import be.ucll.service.PublicationService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;



@RestController
@RequestMapping("/publications")
public class PublicationRestController {
    private PublicationService publicationService;

    @Autowired
    public PublicationRestController(PublicationService publicationService){
        this.publicationService = publicationService;
    }

    public List<Publication> getAllPublications() {
        return publicationService.getAllPublications();
    }

    public List<Publication> getAllPublicationsBook() {
        return publicationService.getAllPublicationsBook();
    }

    public List<Publication> getAllPublicationsMagazine() {
        return publicationService.getAllPublicationsMagazine();
    }

    @GetMapping
    public List<Publication> findPublicationsBytitleAndType(@RequestParam(required = false) String title, String type) {
        return publicationService.findPublicationsByTitleAndType(title, type);
    }

    @GetMapping("/stock/{availableCopies}")
    public List<Publication> findPublicationsByAvailableCopies(@PathVariable int availableCopies){
        return publicationService.findPublicationsByAvailableCopies(availableCopies);
    }
    
}
