package be.ucll.controller;
import be.ucll.model.*;
import be.ucll.service.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/users") 
public class UserRestController {
    private UserService userService;
    private LoanService loanService;

    @Autowired
    public UserRestController(UserService userService, LoanService loanService){
        this.userService = userService;
        this.loanService = loanService;
    }

    @GetMapping
    public List<User> getAllUsers(@RequestParam(required = false) String name){
        if(name == null || name.isEmpty()){
            return userService.getAllUsers();

        }else {
            return userService.getUsersByName(name);
        }
    }

    @GetMapping("/adults")
    public List<User> getAllAdultUsers(){
        return userService.getAllAdultUsers();
    }

    @GetMapping("/age/{min}/{max}")
    public List<User> getUsersByAgeRange(@PathVariable int min, @PathVariable int max){
        return userService.getUsersByAgeRange(min, max);
    }

    @GetMapping("/{email}/loans")
    public List<Loan> getLoansForUser(@PathVariable String email, @RequestParam(required = false, defaultValue = "false") boolean onlyActive) {
        return loanService.getLoansByUser(email, onlyActive);
    }

    
    @PostMapping
    public ResponseEntity<User> addUser(@Valid @RequestBody User user){
        User newUser = userService.addUser(user);
        return ResponseEntity.ok(newUser);
    }

    @PutMapping("/{email}")
    public User updateUser(@PathVariable String email, @Valid @RequestBody User user){
        return userService.updateUser(email, user);
    }

    @DeleteMapping("/{email}/loans")
    public ResponseEntity<String> deleteUserByLoans(@PathVariable String email){
        loanService.deleteLoansByUser(email);
        return ResponseEntity.ok("Loans of user successfully deleted.");
    }

    @DeleteMapping("/{email}")
    public ResponseEntity<String> deleteUsers(@PathVariable String email){
        userService.deleteUser(email);
        return ResponseEntity.ok("User successfully deleted.");
    }
    

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ServiceException.class)
    public Map<String, String> handleServiceException(ServiceException ex) {
        return errorResponse("ServiceException", ex.getField(), ex.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(DomainException.class)
    public Map<String, String> handleDomainException(DomainException ex) {
        return errorResponse("DomainException", null, ex.getMessage());
    }

    private Map<String, String> errorResponse(String errorType, String field, String message) {
        Map<String, String> errorResponse = new HashMap<>();
        errorResponse.put(errorType, message);
        if (field != null) {
            errorResponse.put("field", field);
        }
        return errorResponse;
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler({MethodArgumentNotValidException.class})
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        for (FieldError error : ex.getFieldErrors()) {
            String fieldName = error.getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        }
        return errors;
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler({IllegalArgumentException.class})
    public Map<String, String> handleIllegalArgumentException(IllegalArgumentException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("Illegal Argument", ex.getMessage());
        return errors;
    }

}
    


