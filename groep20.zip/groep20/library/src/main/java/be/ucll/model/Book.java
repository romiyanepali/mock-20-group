package be.ucll.model;
import jakarta.validation.constraints.*;

public class Book extends Publication{

    @NotBlank(message = "Author is required.")
    private String author;

    @NotBlank(message = "ISBN must be given.")
    @Size(min = 13, max = 13, message = "ISBN must have 13 characters.")
    private String isbn;

    public Book(String title, int publicationYear, int availableCopies, String author, String isbn){
       super(title, publicationYear, availableCopies);
       this.author = author;
       this.isbn = isbn;
    }

    public String getAuthor() {
        return author;
    }

    public String getIsbn() {
        return isbn;
    }

    
   
    @Override
    public String toString() {
        return "Book{" +
                "title='" +super.getTitle() + '\'' +
                ", author='" + author + '\'' +
                ", ISBN=" + isbn +
                ", publicationYear=" + super.getPublicationYear() +
                ", number of available copies=" + super.getAvailableCopies() +
                '}';
    }

    @Override
    public String getType() {
        return "Book";
    }
   
}
