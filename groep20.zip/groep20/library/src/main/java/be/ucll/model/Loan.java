package be.ucll.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.validation.constraints.*;

public class Loan {

    private User user;
    
    private List<Publication> publications;

    @NotNull(message = "Start date is required.")
    @PastOrPresent(message = "Start date cannot be in the future.") 
    private LocalDate startDate;

    @PastOrPresent(message = "End date cannot be in the future.") 
    private LocalDate endDate;

    public Loan(User user, List<Publication> publications, LocalDate startDate, LocalDate endDate) {
        this.user = user;
        setPublications(publications);
        this.startDate = startDate;
        setEndDate(endDate);
    }

    public void setPublications(List<Publication> publications){
        for (Publication publication : publications) {
            if (!publication.isAvailable()) {
                throw new DomainException("Unable to lend publication. No copies available for " + publication.getTitle() + ".");
            }else{
                publication.lendPublication();
            } 
        }
        this.publications = new ArrayList<>(publications);
    }


    public void setEndDate(LocalDate endDate){
        if (endDate == null){
            
        }else{
            if (endDate.isBefore(startDate)) {
                throw new DomainException("Start date cannot be after end date.");
            }
        }
        this.endDate = endDate;
    }

    public void returnPublications() {
        for (Publication publication : publications) {
            publication.returnPublication();
        }
    }
    
    public User getUser() {
        return user;
    }

    public List<Publication> getPublications() {
        return publications;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public boolean isActive() {
        LocalDate today = LocalDate.now();
        return endDate == null || !endDate.isBefore(today);
    }
}