package be.ucll.model;
import jakarta.validation.constraints.*;

public class Magazine extends Publication{

    @NotBlank(message = "Editor is required.")
    private String editor;

    @NotBlank(message = "ISSN is required.")
    private String issn;

    public Magazine(String title, int publicationYear, int availableCopies, String editor, String issn){
        super(title, publicationYear,availableCopies);
        this.editor = editor;
        this.issn = issn; 
    }

    public String getEditor(){
        return editor;
    }
    
    public String getISSN(){
        return issn;
    }


    @Override
    public String toString() {
        return "Magazine{" +
                "title='" +super.getTitle() + '\'' +
                ", editor='" + editor + '\'' +
                ", ISSN=" + issn +
                ", publicationYear=" + super.getPublicationYear() +
                ", number of available copies=" + super.getAvailableCopies() +
                '}';
    }

    @Override
    public String getType() {
        return "Magazine";
    }

}    
