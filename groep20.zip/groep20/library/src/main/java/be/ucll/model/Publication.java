package be.ucll.model;
import jakarta.validation.constraints.*;

public abstract class Publication {

    @NotBlank(message = "Title is required.")
    private String title;

    @Positive(message = "Publication year must be a positive integer.")
    private int publicationYear;

    @Positive(message = "Number of available copies cannot be a negative number.")
    private int availableCopies;

   
   public Publication(String title, int publicationYear, int availableCopies){
        this.title = title;
        setPublicationYear(publicationYear);
        this.availableCopies =  availableCopies;
   }
    
    public void setPublicationYear(int publicationYear){
        if (publicationYear > getCurrentYear()) {
            throw new DomainException("Publication year cannot be in the future.");
        }
        this.publicationYear = publicationYear;
    }

   public String getTitle(){
        return title;
   }
    public int getPublicationYear(){
        return publicationYear;
    }

    private int getCurrentYear() {
        return java.time.Year.now().getValue();
    }


    public int getAvailableCopies(){
        return availableCopies;
    }

    public boolean isAvailable() {
        return availableCopies > 0;
    }

    public void  lendPublication(){
        availableCopies--;
    }

    public void returnPublication(){
        availableCopies++;
    }

    public abstract String getType();



}
