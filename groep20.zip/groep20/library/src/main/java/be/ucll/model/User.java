package be.ucll.model;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "USERS")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @NotBlank(message = "Name is required.")
    private String name;

    @Size(min = 8, message = "Password must be at least 8 characters long.")
    private String password;

    @Email(message = "Email should be valid.")
    @NotBlank(message = "Eamil is required.")
    private String email;

    @Min(value = 0, message = "Age should not be less than 0")
    @Max(value = 101, message = "Age should not be greater than 101")
    private int age;

    //@OneToOne(cascade = CascadeType.ALL)
    //@JoinColumn(name = "profile_id", referencedColumnName = "id")
    @OneToOne
    @JoinColumn(name = "profile_id")
    private Profile profile;


    protected User() {}

    public User(String name, String password, String email, int age, Profile profile){
        this.name = name;
        this.password = password;
        this.email = email;
        this.age = age;
        this.profile = profile;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }
    
    public int getAge() {
        return age;
    }

    
    public Profile getProfile() {
        return profile;
    }

    public String toString(){
        return "Name: " + name + "\n" + "Password"+ password + "\n" + "Email: " + email + "\n" + "Age" + age + "\n" + 
        "Profile: " + (profile != null ? profile.toString() : "No profile");
    }

    public void updateInformation(String name, String password, String email, int age, Profile profile){
        if (!this.email.equals(email) ){
            throw new DomainException("Email cannot be changed.");
        }

        this.name = name;
        this.password = password;
        this.email = email;
        this.age = age;
        this.profile = profile;
    }

    public void setProfile(Profile profile) {
        if (this.age < 18) {
            throw new DomainException("User must be at least 18 years old to have a profile.");
        }
        this.profile = profile;
    }

}

