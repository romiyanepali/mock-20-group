package be.ucll.repository;

import org.springframework.stereotype.Component;

import be.ucll.model.Profile;
import be.ucll.model.User;
import jakarta.annotation.PostConstruct;

@Component
public class DbInitializer {
    private UserRepository userRepository;
    
    public DbInitializer(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostConstruct
    public void initialize() {
         // Create Profile objects
         Profile profile1 = new Profile("Teacher Science", "Leuven", "Science, reading, cooking");
         Profile profile2 = new Profile("Teacher Maths", "Antwerpen", "Painting, Reading");
         Profile profile3 = new Profile("Teacher Backend", "Leuven", "Cooking");
         Profile profile4 = new Profile("Teacher History", "Gent", "Playing football");
         Profile profile5 = new Profile("Teacher Chemistry", "Brussels", "Studying chemistry");
         Profile profile6 = new Profile("Teacher English", "Hasselt", "Party, art, music");

         User user1 = new User("John Doe", "john1234", "john.doe@ucll.be", 25, profile1);
         User user2 = new User("Jane Toe", "jane1234", "jane.toe@ucll.be", 30, profile2);
         User user3 = new User("Jack Doe", "jack1234", "jack.doe@ucll.be", 5, profile3);
         User user4 = new User("Sarah Doe", "sarah1234", "sarah.doe@ucll.be", 4, profile4);
         User user5 = new User("Birgit Doe", "birgit1234", "birgit.doe@ucll.be", 18, profile5);
         User user6 = new User("Sarah Randy", "sarahRandy1234", "sarah.randy@ucll.be", 17, profile6);


         userRepository.save(user1);
         userRepository.save(user2);
         userRepository.save(user3);
         userRepository.save(user4);
         userRepository.save(user5);
         userRepository.save(user6);
    
    }
}
