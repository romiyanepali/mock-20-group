package be.ucll.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Iterator;

import org.springframework.stereotype.Repository;

import be.ucll.model.Loan;
import be.ucll.model.Profile;
import be.ucll.model.User;
import be.ucll.service.ServiceException;
import be.ucll.model.Publication;

@Repository
public class LoanRepository {
    private List<Loan> loans;
    private final PublicationRepository publicationRepository;
    private final UserRepository userRepository;

    public LoanRepository(PublicationRepository publicationRepository, UserRepository userRepository) {
        this.publicationRepository = publicationRepository;
        this.userRepository = userRepository;
        this.loans = new ArrayList<>();
        createSampleLoans();
    }

    private void createSampleLoans() {
        List<User> users = new ArrayList<>();
         users.add(new User("John Doe", "john1234", "john.doe@ucll.be",25, new Profile("Teacher Science", "Leuven", "Science, reading, cooking")));
         users.add(new User("Jane Toe", "jane1234", "jane.toe@ucll.be", 30, new Profile("Teacher Maths", "Antwerpen", "Painting, Reading")));
         users.add(new User("Jack Doe", "jack1234", "jack.doe@ucll.be", 5, new Profile("Teacher Backend", "Leuven", "Cooking")));
         users.add(new User("Sarah Doe", "sarah1234", "sarah.doe@ucll.be", 4, new Profile("Teacher History", "Gent", "Playing football")));
         users.add(new User("Birgit Doe", "birgit1234", "birgit.doe@ucll.be", 18,  new Profile("Teacher Chemistry", "Brussels", "Studying chemistry")));
         users.add(new User("Sarah Randy", "sarahRandy1234", "sarah.randy@ucll.be", 17, new Profile("Teacher English", "Hasselt", "Party, art, music")));

        List<Publication> publications1 = Arrays.asList(publicationRepository.allPublicationsBook().get(0), publicationRepository.allPublicationsMagazine().get(2));
        List<Publication> publications2 = Arrays.asList(publicationRepository.allPublicationsBook().get(2), publicationRepository.allPublicationsMagazine().get(0), publicationRepository.allPublicationsMagazine().get(3));
        List<Publication> publications3 = Arrays.asList(publicationRepository.allPublicationsBook().get(1), publicationRepository.allPublicationsMagazine().get(2));
        List<Publication> publications4 = Arrays.asList(publicationRepository.allPublicationsBook().get(1));
    
        this.loans.add(new Loan(users.get(1), publications1, LocalDate.parse("2024-03-24"), null));
        this.loans.add(new Loan(users.get(3), publications2, LocalDate.parse("2023-12-02"), LocalDate.parse("2024-01-02")));
        this.loans.add(new Loan(users.get(0), publications3, LocalDate.parse("2024-04-04"), null));
        this.loans.add(new Loan(users.get(5), publications4, LocalDate.parse("2023-06-10"), LocalDate.parse("2023-07-10")));
        this.loans.add(new Loan(users.get(5), publications4, LocalDate.parse("2023-03-24"), LocalDate.parse("2023-04-24")));
        this.loans.add(new Loan(users.get(3), publications4, LocalDate.parse("2023-06-10"),null));
    }

    public List<Loan> findLoansByUser(String email, boolean onlyActive) {
        List<Loan> userLoans = new ArrayList<>();
        for (Loan loan : loans) {
            if (loan.getUser().getEmail().equals(email)) {
                if (!onlyActive || (onlyActive && loan.getEndDate() == null)) {
                    userLoans.add(loan);
                }
            }
        }
        return userLoans;
    }

    public void deleteByUser(String email){
        Iterator<Loan> iterator = loans.iterator();
        while(iterator.hasNext()){
            Loan loan = iterator.next();
            if(loan.getUser().getEmail().equals(email)){
                if(loan.getEndDate() != null){
                    throw new ServiceException("User has active loans.");
                }else {
                    iterator.remove();
                }
            }
        }
    }

}
