package be.ucll.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import be.ucll.model.Publication;
import be.ucll.model.Book;
import be.ucll.model.Magazine;

@Repository
public class PublicationRepository {
    public List<Publication> publicationsBook;
    public List<Publication> publicationsMagazine;

    public PublicationRepository() {
        publicationsBook = new ArrayList<>();
        publicationsBook.add(new Book("The Great Gatsby", 2000, 10, "John Smith", "1234567890123"));
        publicationsBook.add(new Book("To Kill a Mockingbird", 2010, 5, "Emma Johnson", "9876543210987"));
        publicationsBook.add(new Book("Harry Potter and the Philosopher's Stone", 1997, 8, "J.K. Rowling", "1231231231231"));

        publicationsMagazine = new ArrayList<>();
        publicationsMagazine.add(new Magazine("National Geographic", 1995, 5, "Emily Wilson", "ISSN123"));
        publicationsMagazine.add(new Magazine("Time", 2006, 3, "Daniel Thompson", "ISSN456"));
        publicationsMagazine.add(new Magazine("Scientific American", 2022, 6, "Sophia Martinez", "ISSN789"));
        publicationsMagazine.add(new Magazine("The Great Gatsby", 2000, 6, "John Smith", "ISSN675"));
    }    

    public List<Publication> allPublicationsBook() {
        return publicationsBook;
    }

    public List<Publication> allPublicationsMagazine(){
        return publicationsMagazine;
    }

    public List<Publication> allpublications(){
        List<Publication>allPublications = new ArrayList<>();
        allPublications.addAll(publicationsBook);
        allPublications.addAll(publicationsMagazine);
        return allPublications;
    }
    
    public void resetRepositoryData(){
        publicationsBook.clear();
        publicationsBook.add(new Book("The Great Gatsby", 2000, 10, "John Smith", "1234567890123"));
        publicationsBook.add(new Book("To Kill a Mockingbird", 2010, 5, "Emma Johnson", "9876543210987"));
        publicationsBook.add(new Book("Harry Potter and the Philosopher's Stone", 1997, 8, "J.K. Rowling", "1231231231231"));
    
        publicationsMagazine.clear();
        publicationsMagazine.add(new Magazine("National Geographic", 1995, 5, "Emily Wilson", "ISSN123"));
        publicationsMagazine.add(new Magazine("Time", 2006, 3, "Daniel Thompson", "ISSN456"));
        publicationsMagazine.add(new Magazine("Scientific American", 2022, 6, "Sophia Martinez", "ISSN789"));
        publicationsMagazine.add(new Magazine("The Great Gatsby", 2000, 6, "John Smith", "ISSN675"));
    }

}
