package be.ucll.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import be.ucll.model.Loan;
import be.ucll.repository.LoanRepository;
import be.ucll.repository.PublicationRepository;
import be.ucll.repository.UserRepository;
import be.ucll.service.ServiceException;

@Service
public class LoanService {
    private UserRepository userRepository;
    private LoanRepository loanRepository;
    private PublicationRepository publicationRepository;

    @Autowired
    public LoanService(UserRepository userRepository, LoanRepository loanRepository, PublicationRepository publicationRepository) {
        this.userRepository = userRepository;
        this.loanRepository = loanRepository;
        this.publicationRepository = publicationRepository;
    }

    public List<Loan> getLoansByUser(String email, boolean onlyActive) {
        if (userRepository.findByEmail(email) == null) {
            throw new ServiceException("User with the email not found.");
        }
        return loanRepository.findLoansByUser(email, onlyActive);
    }

    public void deleteLoansByUser(String email){
        if(userRepository.findByEmail(email) == null){
            throw new ServiceException("User does not exist.");
        }
        
        List<Loan> userLoans = loanRepository.findLoansByUser(email, false);

        if(userLoans.isEmpty()){
            throw new ServiceException("User has no loans.");
        }

        loanRepository.deleteByUser(email);
    }

}