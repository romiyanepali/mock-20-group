package be.ucll.service;

import java.util.ArrayList;
import java.util.List;


import org.springframework.stereotype.Service;

import be.ucll.model.Publication;
import be.ucll.repository.PublicationRepository;

@Service
public class PublicationService {
    private PublicationRepository publicationRepository;


    public PublicationService(PublicationRepository publicationRepository) {
        this.publicationRepository = publicationRepository;
    }

    public List<Publication> getAllPublications() {
        return publicationRepository.allpublications();
    }

    public List<Publication> getAllPublicationsBook(){
        return publicationRepository.allPublicationsBook();
    }

    public List<Publication> getAllPublicationsMagazine(){
        return publicationRepository.allPublicationsMagazine();
    }



    public List<Publication> findPublicationsByTitleAndType(String title, String type){
        List<Publication> filteredPublications = new ArrayList<>();
        List<Publication>allPublications = publicationRepository.allpublications();

        if (title == null && type == null) {
            return allPublications;
        }
        if (title == null && type != null){
            if ("book".equalsIgnoreCase(type)) {
                filteredPublications.addAll(publicationRepository.allPublicationsBook());
            } else if ("magazine".equalsIgnoreCase(type)) {
                filteredPublications.addAll(publicationRepository.allPublicationsMagazine());
            }
        }
        if (title != null && type == null){
            for (Publication publication : allPublications) {
                if (publication.getTitle().toLowerCase().contains(title.toLowerCase())) {
                    filteredPublications.add(publication);
                }
            }
        }
    
        if (title != null && type != null) {
            for (Publication publication : allPublications) {
                if (publication.getTitle().toLowerCase().contains(title.toLowerCase()) &&
                        publication.getType().equalsIgnoreCase(type)) {
                    filteredPublications.add(publication);
                }
            }
        }
        return filteredPublications;
    }

    public List<Publication> findPublicationsByAvailableCopies(int availableCopies){
        List<Publication> filteredPublications = new ArrayList<>();
        List<Publication>allPublications = publicationRepository.allpublications();
        
        for (Publication publication : allPublications) {
            if (publication.getAvailableCopies() >= availableCopies) 
                filteredPublications.add(publication);
        }
        return filteredPublications;
    }
}
