package be.ucll.service;

import be.ucll.model.DomainException;
import be.ucll.model.Profile;
import be.ucll.model.User;
import java.util.List;
import be.ucll.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserService {
    private final UserRepository userRepository;
    private final LoanRepository loanRepository;
    private final ProfileRepository profileRepository;

    @Autowired
    public UserService(UserRepository userRepository, LoanRepository loanRepository, ProfileRepository profileRepository){
        this.userRepository = userRepository;
        this.loanRepository = loanRepository;
        this.profileRepository = profileRepository;
    }


    public List<User> getAllUsers(){
        return userRepository.findAll();
    }

    public List<User> getAllAdultUsers(){
        return userRepository.findByAgeGreaterThan(17);
    }
    
    public List<User> getUsersByAgeRange(int minAge, int maxAge){
        if (minAge>=maxAge){
            throw new ServiceException("Minimum age cannot be greater than maximum age.");
        } else if (minAge < 0 || minAge > 150 || maxAge > 150){
            throw new ServiceException("Invalid age range. Age must be between 0 and 150.");
        }
        return userRepository.findByAgeBetween(minAge, maxAge);
    }


    public List<User> getUsersByName(String name){
        List<User> users = userRepository.findByNameContaining(name);
            if (users.isEmpty()) {
                throw new ServiceException("No users found with the specified name.");
            }
        return users;
    }

    public List<User> getUsersByNameAndAge(String name, int age){
        return userRepository.findByNameContainingAndAge(name,age);
    }

    public User addUser(User user){
        if (userRepository.findByEmail(user.getEmail()) != null){
            throw new ServiceException("User already exists!");
        }
        if (user.getProfile() != null) {
            if (user.getAge() < 18) {
                throw new DomainException("User must be at least 18 years old to have a profile.");
            }
            Profile profile = user.getProfile();
            if (profile.getBio() == null || profile.getBio().isEmpty()) {
                throw new DomainException("Bio is required.");
            }
            if (profile.getLocation() == null || profile.getLocation().isEmpty()) {
                throw new DomainException("Location is required.");
            }
            if (profile.getInterests() == null || profile.getInterests().isEmpty()) {
                throw new DomainException("Interests are required.");
            }
             // Save the profile first
            Profile savedProfile = profileRepository.save(profile);
            // Set the saved profile to the user
            user.setProfile(savedProfile);
        }
        return userRepository.save(user);
    }

    public User updateUser(String email, User newInformation){
        User existingUser = userRepository.findByEmail(email);
        if (existingUser == null) {
            throw new ServiceException("User does not exist.");
        }
        if(!email.equals(newInformation.getEmail())){
            throw new ServiceException("Email cannot be changed.");
        }
        existingUser.updateInformation(newInformation.getName(), newInformation.getPassword(), newInformation.getEmail(), newInformation.getAge(), newInformation.getProfile());
        return userRepository.save(existingUser);
    }

    public boolean userExists(String email){
        User user = userRepository.findByEmail(email);
        if (user == null){
            return false;
        }
        return true;
    };

    public void deleteUser(String email){
        User user = userRepository.findByEmail(email);
        if(user == null){
            throw new ServiceException("User does not exist.");
        }

        if(!(loanRepository.findLoansByUser(email, true)).isEmpty()){
            throw new ServiceException("User has active loans.");
        }
        userRepository.delete(user);
    }
}


    

