package be.ucll.integration;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.client.AutoConfigureWebClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;

import be.ucll.repository.*;
import be.ucll.service.*;
import be.ucll.model.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWebClient
public class PublicationIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;
    private PublicationRepository publicationRepository;

    @BeforeEach
    public void setUp(){
        publicationRepository = new PublicationRepository();

    }

    @AfterEach
    public void resetData() {
        publicationRepository.resetRepositoryData();
    }

    @Test
    public void givenTitleAndType_whenGetPublications_thenPublicationsAreReturned() {
        webTestClient
            .get().uri( "/publications?title=the&type=book")
            .exchange()
            .expectStatus().isOk()
            .expectBody()
            .json("[{\"title\": \"The Great Gatsby\", \"publicationYear\": 2000, \"availableCopies\": 9, \"author\": \"John Smith\", \"isbn\": \"1234567890123\", \"type\": \"Book\", \"available\": true}, {\"title\": \"Harry Potter and the Philosopher's Stone\", \"publicationYear\": 1997, \"availableCopies\": 7, \"author\": \"J.K. Rowling\", \"isbn\": \"1231231231231\", \"type\": \"Book\", \"available\": true}]"); 
    }

    @Test
    public void givenAvailableCopies_whenGetPublications_thenPublicationsAreReturned() {
        webTestClient
            .get().uri( "/publications/stock/5")
            .exchange()
            .expectStatus().isOk()
            .expectBody()
            .json("[{\"title\": \"The Great Gatsby\", \"publicationYear\": 2000, \"availableCopies\": 9, \"author\": \"John Smith\", \"isbn\": \"1234567890123\", \"type\": \"Book\", \"available\": true}, {\"title\": \"Harry Potter and the Philosopher's Stone\", \"publicationYear\": 1997, \"availableCopies\": 7, \"author\": \"J.K. Rowling\", \"isbn\": \"1231231231231\", \"type\": \"Book\", \"available\": true}, {\"title\": \"The Great Gatsby\", \"publicationYear\": 2000, \"availableCopies\": 5, \"editor\": \"John Smith\", \"issn\": \"ISSN675\", \"type\": \"Magazine\", \"available\": true}]"); 
    }
 
}    