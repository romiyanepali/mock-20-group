package be.ucll.integration;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.reactive.server.WebTestClient;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;

import be.ucll.model.User;
import be.ucll.repository.DbInitializer;
import be.ucll.repository.UserRepository;
import be.ucll.repository.UserRowMapper;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWebTestClient
@Sql("classpath:schema.sql")
public class UserIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;
    
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DbInitializer dbInitializer;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @BeforeEach
    public void setup() {
        dbInitializer.initialize();
    }

    @Test
    public void givenUsers_whenGetUsers_thenUsersAreReturned() {
        webTestClient
            .get().uri("/users")
            .exchange()
            .expectStatus().isOk()
            .expectBody()
            .json("[{\"name\":\"John Doe\",\"password\":\"john1234\",\"email\":\"john.doe@ucll.be\",\"age\":25},{\"name\":\"Jane Toe\",\"password\":\"jane1234\",\"email\":\"jane.toe@ucll.be\",\"age\":30},{\"name\":\"Jack Doe\",\"password\":\"jack1234\",\"email\":\"jack.doe@ucll.be\",\"age\":5},{\"name\":\"Sarah Doe\",\"password\":\"sarah1234\",\"email\":\"sarah.doe@ucll.be\",\"age\":4},{\"name\":\"Birgit Doe\",\"password\":\"birgit1234\",\"email\":\"birgit.doe@ucll.be\",\"age\":18},{\"name\":\"Sarah Randy\",\"password\":\"sarahRandy1234\",\"email\":\"sarah.randy@ucll.be\",\"age\":17}]"); 
    }

    @Test
    public void givenAdults_whenGetUsers_thenAdultsAreReturned() {
        webTestClient
            .get().uri("/users/adults")
            .exchange()
            .expectStatus().isOk()
            .expectBody()
            .json("[{\"name\": \"John Doe\", \"password\": \"john1234\", \"email\": \"john.doe@ucll.be\", \"age\": 25}, {\"name\": \"Jane Toe\", \"password\": \"jane1234\", \"email\": \"jane.toe@ucll.be\", \"age\": 30}, {\"name\": \"Birgit Doe\", \"password\": \"birgit1234\", \"email\": \"birgit.doe@ucll.be\", \"age\": 18}]"); 
    }

    @Test
    public void givenUserBirgit_whenGetUsers_thenBirgitIsReturned() {
        webTestClient
            .get().uri("/users?name=Birgit")
            .exchange()
            .expectStatus().isOk()
            .expectBody()
            .json("[{\"name\": \"Birgit Doe\", \"password\": \"birgit1234\", \"email\": \"birgit.doe@ucll.be\", \"age\": 18}]"); 
    }

    @Test
    public void givenAgeMin25Max60_whenGetUsers_thenUsersAreReturned() {
        webTestClient
            .get().uri("/users/age/25/60")
            .exchange()
            .expectStatus().isOk()
            .expectBody()
            .json("[{\"name\":\"John Doe\",\"password\":\"john1234\",\"email\":\"john.doe@ucll.be\",\"age\":25},{\"name\":\"Jane Toe\",\"password\":\"jane1234\",\"email\":\"jane.toe@ucll.be\",\"age\":30}]"); 
    }

    @Test
    public void givenEmail_whenGetLoansByUser_thenLoansAreReturned() {
        webTestClient
            .get().uri("users/sarah.randy@ucll.be/loans")
            .exchange()
            .expectStatus().isOk()
            .expectBody()
            .json("[{\"user\":{\"name\":\"Sarah Randy\",\"password\":\"sarahRandy1234\",\"email\":\"sarah.randy@ucll.be\",\"age\":17},\"publications\":[{\"title\":\"To Kill a Mockingbird\",\"publicationYear\":2010,\"availableCopies\":1,\"author\":\"Emma Johnson\",\"isbn\":\"9876543210987\",\"type\":\"Book\",\"available\":true}],\"startDate\":\"2023-06-10\",\"endDate\":\"2023-07-10\",\"active\":false},{\"user\":{\"name\":\"Sarah Randy\",\"password\":\"sarahRandy1234\",\"email\":\"sarah.randy@ucll.be\",\"age\":17},\"publications\":[{\"title\":\"To Kill a Mockingbird\",\"publicationYear\":2010,\"availableCopies\":1,\"author\":\"Emma Johnson\",\"isbn\":\"9876543210987\",\"type\":\"Book\",\"available\":true}],\"startDate\":\"2023-03-24\",\"endDate\":\"2023-04-24\",\"active\":false}]"); 
    }

    @Test
    public void givenNoUserJohn_whenInvokingPostUser_thenUserJohnIsSaved() {
        webTestClient
            .post()
            .uri("/users")
            .header("Content-Type", "application/json")
            .bodyValue("{\"name\":\"John Smith\",\"password\":\"john567890\",\"email\":\"john_smith@ucll.be\",\"age\":25}")
            .exchange()
            .expectStatus().isOk()
            .expectBody()
            .json("{\"name\":\"John Smith\",\"password\":\"john567890\",\"email\":\"john_smith@ucll.be\",\"age\":25}");
   
        User user = jdbcTemplate.queryForObject("SELECT * FROM USERS WHERE email = ?", new UserRowMapper(), "john_smith@ucll.be");
        Assertions.assertNotNull(user);
        Assertions.assertEquals("John Smith", user.getName());
    }

    @Test
    public void givenUserWithInvalidAge_whenInvokingPostUser_thenServiceExceptionIsThrown() {
        webTestClient
        .post()
        .uri("/users")
        .header("Content-Type", "application/json")
        .bodyValue("{\"name\":\"Jacob Smith\",\"password\":\"john567890\",\"email\":\"jacob.doesmith@ucll.be\",\"age\":150}")
        .exchange()
        .expectStatus().isBadRequest()
        .expectBody(String.class)
        .value(response -> {
            Assertions.assertEquals("{\"age\":\"Age should not be greater than 101\"}", response);
        });;
        
        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM USERS WHERE email = ?", Integer.class, "Jacob.doe@ucll.be");
        Assertions.assertEquals(0, count);
    }
    

    @Test
    public void givenUserBirgit_whenInvokingUpdateBirgit_thenNewInformationIsSavedInDb() {
        webTestClient.put()
            .uri("/users/birgit.doe@ucll.be")
            .header("Content-Type", "application/json")
            .bodyValue("{\"name\": \"Birgit Doe\", \"password\": \"birgit1234\", \"email\": \"birgit.doe@ucll.be\", \"age\": 20}")
            .exchange()
            .expectStatus().isOk()
            .expectBody()
            .json("{\"name\": \"Birgit Doe\", \"password\": \"birgit1234\", \"email\": \"birgit.doe@ucll.be\", \"age\": 20}");
        
        User updatedUser = jdbcTemplate.queryForObject("SELECT * FROM USERS WHERE email = ?", new UserRowMapper(), "birgit.doe@ucll.be");
        Assertions.assertNotNull(updatedUser);
        Assertions.assertEquals(20, updatedUser.getAge());
    }

    @Test
    public void givenNewEmail_whenInvokingUpdate_thenServiceExceptionIsThrown() {
        webTestClient.put()
            .uri("/users/birgit.doe@ucll.be")
            .header("Content-Type", "application/json")
            .bodyValue("{\"name\": \"Jacob Doe\", \"password\": \"jacobb1234\", \"email\": \"birgit.doe50@ucll.be\", \"age\": 20}")
            .exchange()
            .expectStatus().isBadRequest()
            .expectBody(String.class)
            .value(response -> {
                Assertions.assertEquals("{\"ServiceException\":\"Email cannot be changed.\"}", response);
            });
        
        User updatedUser = jdbcTemplate.queryForObject("SELECT * FROM USERS WHERE email = ?", new UserRowMapper(), "birgit.doe@ucll.be");
        Assertions.assertNotNull(updatedUser);
        Assertions.assertEquals("birgit.doe@ucll.be", updatedUser.getEmail());
    }

    @Test
    public void givenInexistentUser_whenInvokingUpdate_thenServiceExceptionIsThrown() {
        webTestClient.put()
            .uri("/users/Jacob.doe@ucll.be")
            .header("Content-Type", "application/json")
            .bodyValue("{\"name\": \"Jacob Doe\", \"password\": \"jacobb1234\", \"email\": \"Jacob.doe@ucll.be\", \"age\": 29}")
            .exchange()
            .expectStatus().isBadRequest()
            .expectBody(String.class)
            .value(response -> {
                Assertions.assertEquals("{\"ServiceException\":\"User does not exist.\"}", response);
            });
        
        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM USERS WHERE email = ?", Integer.class, "Jacob.doe@ucll.be");
        Assertions.assertEquals(0, count);
    }

    @Test
    public void givenUserBirgit_whenInvokingDeleteBirgit_thenUserBirgitIsRemoved() {
        webTestClient.delete()
        .uri("/users/birgit.doe@ucll.be")
        .exchange()
        .expectStatus().isOk()
        .expectBody(String.class)
        .value(response -> {
            Assertions.assertEquals("User successfully deleted.", response);
        });
        
        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM USERS WHERE email = ?", Integer.class, "birgit.doe@ucll.be");
        Assertions.assertEquals(0, count);
    }

    @Test
    public void givenUnexistingUser_whenInvokingDeleteUser_thenServiceExceptionIsThrown() {
        webTestClient.delete()
            .uri("/users/Jacob.doe@ucll.be")
            .exchange()
            .expectStatus().isBadRequest()
            .expectBody(String.class)
            .value(response -> {
                Assertions.assertEquals("{\"ServiceException\":\"User does not exist.\"}", response);
            });

        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM USERS WHERE email = ?", Integer.class, "Jacob.doe@ucll.be");
        Assertions.assertEquals(0, count);
    }

}
