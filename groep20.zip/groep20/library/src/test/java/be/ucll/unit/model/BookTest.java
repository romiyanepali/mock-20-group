package be.ucll.unit.model;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import be.ucll.model.Book;
import be.ucll.model.DomainException;

import java.util.Set;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.ValidatorFactory;
import jakarta.validation.Validator;

public class BookTest{
    private static ValidatorFactory validatorFactory;
    private static Validator validator;

    @BeforeAll
    public static void createValidator() {
        validatorFactory = Validation.buildDefaultValidatorFactory();
        validator = validatorFactory.getValidator();
    }

    @Test
    public void givenValidValues_whenCreatingBook_thenBookIsCreatedWithThoseValues(){
        Book book = new Book("Verdubbel je geld", 2019, 4, "Sam Hollanders", "9789401464413");

        assertEquals("Verdubbel je geld", book.getTitle());
        assertEquals("Sam Hollanders", book.getAuthor());
        assertEquals(4, book.getAvailableCopies());
        assertEquals("9789401464413", book.getIsbn());
        assertEquals(2019, book.getPublicationYear());
    }

    @Test 
    void givenNoTitle_whenCreatingBook_thenTitleViolationIsThrown(){
        Book book1 = new Book(null, 2019, 4, "Sam Hollanders", "9789401464413");

        Set<ConstraintViolation<Book>> violations = validator.validate(book1);
        assertEquals(1, violations.size());

        ConstraintViolation<Book> violation = violations.iterator().next();
        assertEquals("Title is required.", violation.getMessage());
    }

    @Test 
    void givenNegativePublicationYear_whenCreatingBook_thenPublicationYearViolationIsThrown(){
        Book book1 = new Book("Verdubbel je geld", -2019, 4, "Sam Hollanders", "9789401464413");

        Set<ConstraintViolation<Book>> violations = validator.validate(book1);
        assertEquals(1, violations.size());
        
        ConstraintViolation<Book> violation = violations.iterator().next();
        assertEquals("Publication year must be a positive integer.", violation.getMessage());
    }

    @Test
    public void givenInvalidPublicationYear_whenCreatingMagazine_thenExceptionErrorIsThrown(){
        Exception ex1 = Assertions.assertThrows(DomainException.class, 
        () -> {
             new Book("Verdubbel je geld", 3050, 4, "Sam Hollanders", "9789401464413");
        });
        Assertions.assertEquals("Publication year cannot be in the future.", ex1.getMessage());

    }

    @Test 
    void givenNegativeAvailableCopies_whenCreatingBook_thenAvailableCopesViolationIsThrown(){
        Book book1 = new Book("Verdubbel je geld", 2019, -7, "Sam Hollanders", "9789401464413");

        Set<ConstraintViolation<Book>> violations = validator.validate(book1);
        assertEquals(1, violations.size());
        
        ConstraintViolation<Book> violation = violations.iterator().next();
        assertEquals("Number of available copies cannot be a negative number.", violation.getMessage());
    }

    @Test 
    void givenNoAuthor_whenCreatingBook_thenAuthorViolationIsThrown(){
        Book book1 = new Book("Verdubbel je geld", 2019, 4, null, "9789401464413");

        Set<ConstraintViolation<Book>> violations = validator.validate(book1);
        assertEquals(1, violations.size());

        ConstraintViolation<Book> violation = violations.iterator().next();
        assertEquals("Author is required.", violation.getMessage());
    }

    @Test 
    void givenNoISBN_whenCreatingBook_thenISBNYearViolationIsThrown(){
        Book book1 = new Book("Verdubbel je geld", 2019, 4, "Sam Hollanders", null);

        Set<ConstraintViolation<Book>> violations = validator.validate(book1);
        assertEquals(1, violations.size());
        
        ConstraintViolation<Book> violation = violations.iterator().next();
        assertEquals("ISBN must be given.", violation.getMessage());
    }

    @Test 
    void givenInvalidISBN_whenCreatingBook_thenISBNYearViolationIsThrown(){
        Book book1 = new Book("Verdubbel je geld", 2019, 4, "Sam Hollanders", "12345678901234567");

        Set<ConstraintViolation<Book>> violations = validator.validate(book1);
        assertEquals(1, violations.size());
        
        ConstraintViolation<Book> violation = violations.iterator().next();
        assertEquals("ISBN must have 13 characters.", violation.getMessage());
    }

    @AfterAll
    public static void close() {
        validatorFactory.close();
    }

}