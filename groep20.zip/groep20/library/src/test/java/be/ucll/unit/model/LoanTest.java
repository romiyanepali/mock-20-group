package be.ucll.unit.model;
import be.ucll.model.*;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import java.util.Set;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.ValidatorFactory;
import jakarta.validation.Validator;

public class LoanTest {
    private static ValidatorFactory validatorFactory;
    private static Validator validator;

    @BeforeAll
    public static void createValidator() {
        validatorFactory = Validation.buildDefaultValidatorFactory();
        validator = validatorFactory.getValidator();
    }

    @Test
    public void givenValidValues_whenCreatingLoan_thenLoanIsCreatedWithThoseValues(){
        User user = new User("John Smith", "password", "john@example.com", 43, new Profile("Teacher maths and english", "Leuven", "Party, art, music"));

        
        List<Publication> publications = new ArrayList<>();
        publications.add(new Magazine("Title 1",1995, 5, "William Taylor", "1234567"));
        publications.add(new Magazine("Title 2", 2006, 3, "Daniel Davis", "1234789"));


        Loan loan = new Loan(user, publications,LocalDate.parse("2023-12-02"), LocalDate.parse("2024-01-02"));

        assertEquals(user, loan.getUser());
        assertEquals(publications, loan.getPublications());
        assertEquals(LocalDate.parse("2023-12-02"), loan.getStartDate());
        assertEquals( LocalDate.parse("2024-01-02"), loan.getEndDate());
    }

    @Test
    public void copiesNotAvailable_whenCreatingLoan_thenExceptionErrorIsThrown(){
        Exception ex1 = Assertions.assertThrows(DomainException.class, 
        () -> {
            User user = new User("John Smith", "password", "john@example.com", 43, new Profile("Teacher English", "Hasselt", "music"));
        
            List<Publication> publications = new ArrayList<>();
            publications.add(new Magazine("Title 1",1995, 0, "William Taylor", "1234567"));
            publications.add(new Magazine("Title 2", 2006, 3, "Daniel Davis", "1234789"));

            new Loan(user, publications, LocalDate.parse("2023-12-02"), LocalDate.parse("2024-01-02"));
        });
        Assertions.assertEquals("Unable to lend publication. No copies available for Title 1.", ex1.getMessage());
    }

    @Test
    public void givenNoStartDate_whenCreatingLoan_thenStartDateViolationIsThrown(){
        User user = new User("John Smith", "password", "john@example.com", 43, new Profile("Teacher English", "Hasselt", "Party, art, music"));
        
        List<Publication> publications = new ArrayList<>();
        publications.add(new Magazine("Title 1",1995, 6, "William Taylor", "1234567"));
        publications.add(new Magazine("Title 2", 2006, 3, "Daniel Davis", "1234789"));

        Loan loan1 = new Loan(user, publications, null, null );

        Set<ConstraintViolation<Loan>> violations = validator.validate(loan1);
        assertEquals(1, violations.size());

        ConstraintViolation<Loan> violation = violations.iterator().next();
        assertEquals("Start date is required.", violation.getMessage());
    }

    @Test
    public void givenFutureStartDate_whenCreatingLoan_thenStartDateViolationIsThrown(){
        User user = new User("John Smith", "password", "john@example.com", 43, new Profile("Teacher English", "Hasselt", "Party, art, music"));
        
        List<Publication> publications = new ArrayList<>();
        publications.add(new Magazine("Title 1",1995, 6, "William Taylor", "1234567"));
        publications.add(new Magazine("Title 2", 2006, 3, "Daniel Davis", "1234789"));

        Loan loan1 = new Loan(user, publications, LocalDate.parse("2050-12-31"), null );

        Set<ConstraintViolation<Loan>> violations = validator.validate(loan1);
        assertEquals(1, violations.size());

        ConstraintViolation<Loan> violation = violations.iterator().next();
        assertEquals("Start date cannot be in the future.", violation.getMessage());
    }

    @Test
    public void givenFutureEndDate_whenCreatingLoan_thenStartDateViolationIsThrown(){
        User user = new User("John Smith", "password", "john@example.com", 43, new Profile("Teacher English", "Hasselt", "Party, art, music"));
        
        List<Publication> publications = new ArrayList<>();
        publications.add(new Magazine("Title 1",1995, 6, "William Taylor", "1234567"));
        publications.add(new Magazine("Title 2", 2006, 3, "Daniel Davis", "1234789"));

        Loan loan1 = new Loan(user, publications, LocalDate.parse("2022-12-31"), LocalDate.parse("2024-12-31") );

        Set<ConstraintViolation<Loan>> violations = validator.validate(loan1);
        assertEquals(1, violations.size());

        ConstraintViolation<Loan> violation = violations.iterator().next();
        assertEquals("End date cannot be in the future.", violation.getMessage());
    }


    @Test
    public void endDateBeforeStartDate_whenCreatingLoan_thenEndDateViolationIsThrown(){
        Exception ex1 = Assertions.assertThrows(DomainException.class, 
        () -> {
            User user = new User("John Smith", "password", "john@example.com", 43, new Profile("Teacher English", "Hasselt", "Party, art, music"));
      
            List<Publication> publications = new ArrayList<>();
            publications.add(new Magazine("Title 1",1995, 6, "William Taylor", "1234567"));
            publications.add(new Magazine("Title 2", 2006, 3, "Daniel Davis", "1234789"));

            new Loan(user, publications, LocalDate.parse("2022-12-31"), LocalDate.parse("2020-12-31"));
        });
        Assertions.assertEquals("Start date cannot be after end date.", ex1.getMessage());
    }

    @AfterAll
    public static void close() {
        validatorFactory.close();
    }
}
