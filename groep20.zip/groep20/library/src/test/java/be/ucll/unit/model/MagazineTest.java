package be.ucll.unit.model;
import be.ucll.model.DomainException;
import be.ucll.model.Magazine;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;

import java.util.Set;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.ValidatorFactory;
import jakarta.validation.Validator;


public class MagazineTest {
    private static ValidatorFactory validatorFactory;
    private static Validator validator;

    @BeforeAll
    public static void createValidator() {
        validatorFactory = Validation.buildDefaultValidatorFactory();
        validator = validatorFactory.getValidator();
    }
    
    @Test
    public void givenValidValues_whenCreatingMagazine_thenMagazineIsCreatedWithThoseValues(){
        Magazine magazine = new Magazine("TIME", 1923, 8, "Sam Jacobs","0040-781X" );
        assertEquals("TIME", magazine.getTitle());
        assertEquals("Sam Jacobs", magazine.getEditor());
        assertEquals(8, magazine.getAvailableCopies());
        assertEquals("0040-781X", magazine.getISSN());
        assertEquals(1923, magazine.getPublicationYear());
    }

    @Test 
    void givenNoTitle_whenCreatingMagazine_thenTitleViolationIsThrown(){
        Magazine magazine1 = new Magazine(null, 1923, 8, "Sam Jacobs","0040-781X" );

        Set<ConstraintViolation<Magazine>> violations = validator.validate(magazine1);
        assertEquals(1, violations.size());

        ConstraintViolation<Magazine> violation = violations.iterator().next();
        assertEquals("Title is required.", violation.getMessage());
    }

    @Test 
    void givenNegativePublicationYear_whenCreatingMagazine_thenPublicationYearViolationIsThrown(){
        Magazine magazine1 = new Magazine("TIME", -1923, 8, "Sam Jacobs","0040-781X" );

        Set<ConstraintViolation<Magazine>> violations = validator.validate(magazine1);
        assertEquals(1, violations.size());

        ConstraintViolation<Magazine> violation = violations.iterator().next();
        assertEquals("Publication year must be a positive integer.", violation.getMessage());
    }

    @Test
    public void givenInvalidPublicationYear_whenCreatingMagazine_thenExceptionErrorIsThrown(){
        Exception ex1 = Assertions.assertThrows(DomainException.class, 
        () -> {
            new Magazine("TIME",3050 ,8,"Sam Jacobs" , "0040-781X");
        });
        Assertions.assertEquals("Publication year cannot be in the future.", ex1.getMessage());

    }
    
    @Test 
    void givenNegativeAvailableCopies_whenCreatingMagazine_thenAvailableCopiesViolationIsThrown(){
        Magazine magazine1 = new Magazine("TIME", 1923, -8, "Sam Jacobs","0040-781X" );

        Set<ConstraintViolation<Magazine>> violations = validator.validate(magazine1);
        assertEquals(1, violations.size());

        ConstraintViolation<Magazine> violation = violations.iterator().next();
        assertEquals("Number of available copies cannot be a negative number.", violation.getMessage());
    }

    @Test 
    void givenNoEditor_whenCreatingMagazine_thenEditorViolationIsThrown(){
        Magazine magazine1 = new Magazine("TIME", 1923, 8, null,"0040-781X" );

        Set<ConstraintViolation<Magazine>> violations = validator.validate(magazine1);
        assertEquals(1, violations.size());

        ConstraintViolation<Magazine> violation = violations.iterator().next();
        assertEquals("Editor is required.", violation.getMessage());
    }

    @Test 
    void givenNoISSN_whenCreatingMagazine_thenEditorViolationIsThrown(){
        Magazine magazine1 = new Magazine("TIME", 1923, 8, "Sam Jacobs", null);

        Set<ConstraintViolation<Magazine>> violations = validator.validate(magazine1);
        assertEquals(1, violations.size());

        ConstraintViolation<Magazine> violation = violations.iterator().next();
        assertEquals("ISSN is required.", violation.getMessage());
    }

    @AfterAll
    public static void close() {
        validatorFactory.close();
    }

   
}
