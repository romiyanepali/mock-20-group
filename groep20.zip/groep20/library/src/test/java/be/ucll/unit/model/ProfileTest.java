package be.ucll.unit.model;

import static org.junit.jupiter.api.Assertions.*;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import be.ucll.model.Profile;

public class ProfileTest {
    private Validator validator;

    @BeforeEach
    public void setUp(){
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    public void whenBioIsBlank_thenValidationFails() {
        Profile profile = new Profile("", "Leuven", "Science, reading, cooking, movies");
        Set<ConstraintViolation<Profile>> violations = validator.validate(profile);
        assertFalse(violations.isEmpty());
        assertEquals("Bio is required.", violations.iterator().next().getMessage());
    }

    @Test
    public void whenLocationIsBlank_thenValidationFails() {
        Profile profile = new Profile("Teacher at UCLL", "", "Science, reading, cooking, movies");
        Set<ConstraintViolation<Profile>> violations = validator.validate(profile);
        assertFalse(violations.isEmpty());
        assertEquals("Location is required.", violations.iterator().next().getMessage());
    }

    @Test
    public void whenInterestsAreBlank_thenValidationFails() {
        Profile profile = new Profile("Teacher at UCLL", "Leuven", "");
        Set<ConstraintViolation<Profile>> violations = validator.validate(profile);
        assertFalse(violations.isEmpty());
        assertEquals("Interests are required.", violations.iterator().next().getMessage());
    }

    @Test
    public void whenAllFieldsAreValid_thenValidationPasses() {
        Profile profile = new Profile("Teacher at UCLL", "Leuven", "Science, reading, cooking, movies");
        Set<ConstraintViolation<Profile>> violations = validator.validate(profile);
        assertTrue(violations.isEmpty());
    }
}
