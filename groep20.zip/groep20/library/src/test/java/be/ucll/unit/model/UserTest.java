package be.ucll.unit.model;

import be.ucll.model.DomainException;
import be.ucll.model.Profile;
import be.ucll.model.User;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;

import java.util.Set;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.ValidatorFactory;
import jakarta.validation.Validator;

public class UserTest{
    private static ValidatorFactory validatorFactory;
    private static Validator validator;

    @BeforeAll
    public static void createValidator() {
        validatorFactory = Validation.buildDefaultValidatorFactory();
        validator = validatorFactory.getValidator();
    }

    @Test
    public void givenValidValues_whenCreatingUser_thenUserIsCreatedWithThoseValues(){
        Profile profile1 = new Profile("Good parenting is my motto", "Antwerpen", "Cooking");
        User user = new User("Lukas", "password", "lukas@example.com", 25, profile1);
        assertEquals("Lukas", user.getName());
        assertEquals("password", user.getPassword());
        assertEquals("lukas@example.com", user.getEmail());
        assertEquals(25, user.getAge());
        
        Profile userProfile = user.getProfile();
        assertNotNull(userProfile, "Profile should not be null");
        assertEquals("Good parenting is my motto", userProfile.getBio());
        assertEquals("Antwerpen", userProfile.getLocation());
        assertEquals("Cooking", userProfile.getInterests());
    }

    @Test 
    void givenNoName_whenCreatingUser_thenNameViolationIsThrown(){
        Profile profile2 = new Profile("Living in USA", "Antwerp", "Skydiving");
        User user1 = new User(null, "password1234", "orange@gmail.com", 20, profile2);

        Set<ConstraintViolation<User>> violations = validator.validate(user1);
        assertEquals(1, violations.size());
        ConstraintViolation<User> violation = violations.iterator().next();
        assertEquals("Name is required.", violation.getMessage());
    }

    @Test
    void givenInvalidPassword_whenCreatingUser_thenPasswordViolationIsThrown(){
        Profile profile2 = new Profile("Living in USA", "Antwerp", "Skydiving");
        User user1 = new User("David Smith", "pass", "orange@gmail.com", 20, profile2);

        Set<ConstraintViolation<User>> violations = validator.validate(user1);
        assertEquals(1, violations.size());
        ConstraintViolation<User> violation = violations.iterator().next();
        assertEquals("Password must be at least 8 characters long.", violation.getMessage());
    } 

    @Test
    void givenNoEmail_whenCreatingUser_thenEmailViolationIsThrown(){
        Profile profile2 = new Profile("Living in USA", "Antwerp", "Skydiving");
        User user1 = new User("David Smith", "password1234", null, 20, profile2);

        Set<ConstraintViolation<User>> violations = validator.validate(user1);
        assertEquals(1, violations.size());
        ConstraintViolation<User> violation = violations.iterator().next();
        assertEquals("Eamil is required.", violation.getMessage());
    }

    @Test
    void givenInvalidEmail_whenCreatingUser_thenEmailViolationIsThrown(){
        Profile profile2 = new Profile("Living in USA", "Antwerp", "Skydiving");
        User user1 = new User("David Smith", "password1234", "orange.com", 20, profile2);

        Set<ConstraintViolation<User>> violations = validator.validate(user1);
        assertEquals(1, violations.size());
        ConstraintViolation<User> violation = violations.iterator().next();
        assertEquals("Email should be valid.", violation.getMessage());
    }

    @Test
    void givenNegativeAge_whenCreatingUser_thenAgeViolationIsThrown(){
        Profile profile2 = new Profile("Living in USA", "Antwerp", "Skydiving");
        User user1 = new User("David Smith", "password1234", "orange@google.com", -20, profile2);

        Set<ConstraintViolation<User>> violations = validator.validate(user1);
        assertEquals(1, violations.size());
        ConstraintViolation<User> violation = violations.iterator().next();
        assertEquals("Age should not be less than 0", violation.getMessage());
    }

    @Test
    void givenAgeGreaterThan101_whenCreatingUser_thenAgeViolationIsThrown(){
        Profile profile2 = new Profile("Living in USA", "Antwerp", "Skydiving");
        User user1 = new User("David Smith", "password1234", "orange@google.com", 150, profile2);

        Set<ConstraintViolation<User>> violations = validator.validate(user1);
        assertEquals(1, violations.size());
        ConstraintViolation<User> violation = violations.iterator().next();
        assertEquals("Age should not be greater than 101", violation.getMessage());
    }

    @Test
    public void givenInvalidPublicationYear_whenCreatingMagazine_thenExceptionErrorIsThrown(){
        Exception ex1 = Assertions.assertThrows(DomainException.class, 
        () -> {
            Profile profile = new Profile("Developer", "Antwerp", "Programming, hiking");
            User user1 = new User("David Smith", "password1234", "orange@gmail.com", 20, profile);
            user1.updateInformation("David Smith", "password1234", "orangeoo@gmail.com", 20, profile);
        });
        Assertions.assertEquals("Email cannot be changed.", ex1.getMessage());
    }

    @Test
    void givenUserUnder18_whenSettingProfile_thenDomainExceptionIsThrown() {
        Profile profile = new Profile("Student", "Brussels", "Music, traveling");
        User user = new User("Alice", "password123", "alice@example.com", 17, profile);
        

        DomainException exception = assertThrows(DomainException.class, () -> {
            user.setProfile(profile);
        });

        assertEquals("User must be at least 18 years old to have a profile.", exception.getMessage());
    }

    @Test
    void givenUser18OrOlder_whenSettingProfile_thenProfileIsSet() {
        Profile profile = new Profile("Developer", "Antwerp", "Programming, hiking");
        User user = new User("Bob", "password123", "bob@example.com", 18, profile);
        

        user.setProfile(profile);

        assertEquals(profile, user.getProfile());
    }

    @Test
    void givenUserWithProfile_whenUpdatingUser_thenProfileRemainsIntact() {
        Profile profile = new Profile("Designer", "Ghent", "Art, gaming");
        User user = new User("Carol", "password123", "carol@example.com", 25, profile);
       
        user.setProfile(profile);

        user.updateInformation("Carol Updated", "newpassword123", "carol@example.com", 26, profile);

        assertEquals("Carol Updated", user.getName());
        assertEquals("newpassword123", user.getPassword());
        assertEquals(26, user.getAge());
        assertEquals("Designer", profile.getBio());
        assertEquals("Ghent", profile.getLocation());
        assertEquals("Art, gaming", profile.getInterests());
    }

    @AfterAll
    public static void close() {
        validatorFactory.close();
    }

    
}
