package be.ucll.unit.service;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;

import java.util.List;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import be.ucll.service.*;
import be.ucll.service.ServiceException;
import be.ucll.unit.repository.UserRepositoryTestImpl;
import be.ucll.repository.*;
import be.ucll.model.*;

public class LoanServiceTest {
    @Autowired
    private LoanService loanService;
    private LoanRepository loanRepository;
    private PublicationRepository publicationRepository;
    private UserRepositoryTestImpl userRepository;

     @BeforeEach
    public void setUp(){
        publicationRepository = new PublicationRepository();
        userRepository = new UserRepositoryTestImpl();
        loanRepository = new LoanRepository(publicationRepository, userRepository);
        loanService = new LoanService(userRepository, loanRepository, publicationRepository);
    }


    @Test
    public void testGetLoansByUser_validInput(){
        List<Loan> loansByUser1 = loanService.getLoansByUser("sarah.randy@ucll.be", false );
        assertEquals(2, loansByUser1.size());

        List<Loan> loansByUser2 = loanService.getLoansByUser("sarah.doe@ucll.be", false);
        assertEquals(2, loansByUser2.size());

        List<Loan> loansByUser3 = loanService.getLoansByUser("jane.toe@ucll.be", true);
        assertEquals(1, loansByUser3.size());

        List<Loan> loansByUser4 = loanService.getLoansByUser("john.doe@ucll.be", false);
        assertEquals(1, loansByUser4.size());

    }

    @Test
    public void testGetLoansByUser_invalidInput(){
        Exception ex1 = Assertions.assertThrows(ServiceException.class, 
        () -> {
            loanService.getLoansByUser("sarah.randy@gmail.com", false );
        });
        Assertions.assertEquals("User with the email not found.", ex1.getMessage());
        

    }

    @Test 
    public void WhenGiven_NonExistentUser_ThrowsException(){
        Exception exception1 = Assertions.assertThrows(ServiceException.class, ()-> loanService.deleteLoansByUser("romiya.nepali@ucll.be"));
        Exception exception2 = Assertions.assertThrows(ServiceException.class, ()-> loanService.deleteLoansByUser("john.toe@ucll.be"));
        Exception exception3 = Assertions.assertThrows(ServiceException.class, ()-> loanService.deleteLoansByUser(null));
        Assertions.assertEquals("User does not exist.", exception1.getMessage());
        Assertions.assertEquals("User does not exist.", exception2.getMessage());
        Assertions.assertEquals("User does not exist.", exception3.getMessage());
        
    }

    @Test
    public void WhenGiven_NoLoansUser_ThrowsException(){
        Exception exception1 = Assertions.assertThrows(ServiceException.class, ()-> loanService.deleteLoansByUser("birgit.doe@ucll.be"));
        Assertions.assertEquals("User has no loans.", exception1.getMessage());

    }

    @Test 
    public void WhenGiven_UserWithActiveLoan_ThrowsException(){
        Exception exception1 = Assertions.assertThrows(ServiceException.class, ()-> loanService.deleteLoansByUser("sarah.doe@ucll.be"));
        Assertions.assertEquals("User has active loans.", exception1.getMessage());
    }

    @Test
    public void WhenGivenExistentUser_DeletesSuccesfully_ThenGivesAMessage(){
        List<Loan> loansBefore = loanRepository.findLoansByUser("john.doe@ucll.be",false);
        assertFalse(loansBefore.isEmpty(), "User should have loans before deletion");

         
        loanService.deleteLoansByUser("john.doe@ucll.be");

    
        List<Loan> loansAfter = loanRepository.findLoansByUser("john.doe@ucll.be", false);
        assertTrue(loansAfter.isEmpty(), "User's loans should be deleted");
    }
}

