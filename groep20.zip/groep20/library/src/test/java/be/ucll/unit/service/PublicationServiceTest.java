package be.ucll.unit.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import be.ucll.model.Publication;
import be.ucll.repository.PublicationRepository;
import be.ucll.service.PublicationService;

public class PublicationServiceTest {

    @Autowired
    private PublicationService publicationService;

    @BeforeEach
    public void setUp(){
        PublicationRepository publicationRepository = new PublicationRepository();
        publicationService = new PublicationService(publicationRepository);
    }

    @Test
    public void testGetAllPublications(){
        List<Publication> actualPublications = publicationService.getAllPublications();
        assertEquals(7, actualPublications.size());
    }

    @Test 
    public void testGetAllPublicationsBook(){
        List<Publication> actualPublicationsBook = publicationService.getAllPublicationsBook();
        assertEquals(3, actualPublicationsBook.size());
    }

    @Test 
    public void testGetAllPublicationsMagazine(){
        List<Publication> actualPublicationsMagazine = publicationService.getAllPublicationsMagazine();
        assertEquals(4, actualPublicationsMagazine.size());
    }

    @Test 
    public void testFindPublicationsByTitleAndType(){
        List<Publication> PublicationsBytitleAndType1 = publicationService.findPublicationsByTitleAndType("The Great", null);
        assertEquals(2, PublicationsBytitleAndType1.size());

        List<Publication> PublicationsBytitleAndType2 = publicationService.findPublicationsByTitleAndType("Time", "Book");
        assertEquals(0, PublicationsBytitleAndType2.size());

        List<Publication> PublicationsBytitleAndType3 = publicationService.findPublicationsByTitleAndType(null, "Book");
        assertEquals(3, PublicationsBytitleAndType3.size());

        List<Publication> PublicationsBytitleAndType4 = publicationService.findPublicationsByTitleAndType("Time", "Magazine");
        assertEquals(1, PublicationsBytitleAndType4.size());

        List<Publication> PublicationsBytitleAndType5 = publicationService.findPublicationsByTitleAndType(null, "Magazine");
        assertEquals(4, PublicationsBytitleAndType5.size());

        List<Publication> PublicationsBytitleAndType6 = publicationService.findPublicationsByTitleAndType(null, null);
        assertEquals(7, PublicationsBytitleAndType6.size());

    }

    @Test
    public void testFindPublicationsByAvailableCopies(){
        List<Publication> PublicationsByAvailableCopies1 = publicationService.findPublicationsByAvailableCopies(3);
        assertEquals(7, PublicationsByAvailableCopies1.size());

        List<Publication> PublicationsByAvailableCopies2 = publicationService.findPublicationsByAvailableCopies(10);
        assertEquals(1, PublicationsByAvailableCopies2.size());

        List<Publication> PublicationsByAvailableCopies3 = publicationService.findPublicationsByAvailableCopies(50);
        assertEquals(0, PublicationsByAvailableCopies3.size());
    }
}
