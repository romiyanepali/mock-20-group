package be.ucll.unit.service;

import be.ucll.model.DomainException;
import be.ucll.model.User;
import be.ucll.repository.LoanRepository;
import be.ucll.repository.ProfileRepository;
import be.ucll.repository.PublicationRepository;
import be.ucll.repository.UserRepository;
import be.ucll.service.UserService;
import be.ucll.unit.repository.ProfileRepositoryTestImpl;
import be.ucll.unit.repository.UserRepositoryTestImpl;
import be.ucll.service.LoanService;
import be.ucll.service.ServiceException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

public class UserServiceTest {
    //@Autowired
    private UserService userService;
    private LoanService loanService;
    private ProfileRepositoryTestImpl profileRepository;
    private UserRepositoryTestImpl userRepository;
    private LoanRepository loanRepository;

    @BeforeEach
    public void setUp() {
        profileRepository = new ProfileRepositoryTestImpl();
        userRepository = new UserRepositoryTestImpl();
        loanRepository = new LoanRepository(new PublicationRepository(), userRepository);
        userService = new UserService(userRepository, loanRepository, profileRepository);
        loanService = new LoanService(userRepository, loanRepository, null);
    }

    @Test
    public void testGetAllUsers(){

        List<User> actualUsers = userService.getAllUsers();
        assertEquals(6, actualUsers.size());
    }

    @Test
    public void testGetAllAdultUsers(){

        List<User> actualUsers = userService.getAllAdultUsers();
        assertEquals(3, actualUsers.size());
    }

    @Test
    public void testGetUsersByAgeRange_ValidRange_ReturnUsers(){
        List<User> actualUsersByAge = userService.getUsersByAgeRange(18,25);
        assertEquals(2, actualUsersByAge.size());
    }

    @Test
    public void testGetUsersByAgeRange_InvalidRange_ThrowsException(){
        assertThrows(ServiceException.class, ()->userService.getUsersByAgeRange(30,18));
        assertThrows(ServiceException.class, ()->userService.getUsersByAgeRange(0,180));
        assertThrows(ServiceException.class, ()->userService.getUsersByAgeRange(-50,180));
    }

    @Test
    public void testGetUsersByName_Valid_ThenReturnUsersByName(){
        List<User> user1 = userService.getUsersByName("John");
        assertEquals(1, user1.size());
        List<User> user2 = userService.getUsersByName("Sarah");
        assertEquals(2, user2.size());
    }

    @Test
    public void testGetUsersByName_Invalid_ThenThrowException(){
        assertThrows(ServiceException.class, () -> userService.getUsersByName("Miyuki"));
        assertThrows(ServiceException.class, () -> userService.getUsersByName("Romiya"));
    }


    @Test 
    public void whenDelete_NonExistentUser_ThrowsException(){
        ServiceException exception1 = Assertions.assertThrows(ServiceException.class, ()-> userService.deleteUser("romiya.nepali@ucll.be"));
        ServiceException exception2 = Assertions.assertThrows(ServiceException.class, ()-> userService.deleteUser("john.toe@ucll.be"));
        ServiceException exception3 = Assertions.assertThrows(ServiceException.class, ()-> userService.deleteUser(null));
        Assertions.assertEquals("User does not exist.", exception1.getMessage());
        Assertions.assertEquals("User does not exist.", exception2.getMessage());
        Assertions.assertEquals("User does not exist.", exception3.getMessage());
    }
   
    @Test
    public void whenDelete_UserHasActiveLoans_ThrowsException(){
        ServiceException exception1 = Assertions.assertThrows(ServiceException.class, ()->userService.deleteUser("john.doe@ucll.be"));
        Assertions.assertEquals("User has active loans.", exception1.getMessage());

    }

    @Test 
    public void whenDeleteUser_UserHadOnlyInactiveLoans_RemoveLoansFirst(){
        userService.deleteUser("birgit.doe@ucll.be");
        assertTrue(loanRepository.findLoansByUser("birgit.doe@ucll.be", true).isEmpty(), "User's incative loans should be removed.");
    }

    @Test
    public void testDeleteUser_UserSuccessfullyDeleted_ReturnsSuccessMessage() {
        userService.deleteUser("birgit.doe@ucll.be");
        assertNull(userRepository.findByEmail("birgit.doe@ucll.be"));
    }
}
